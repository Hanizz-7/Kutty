package com.yourname.kutty.ui.theme

import androidx.compose.ui.graphics.Color

val KuttyPrimary = Color(0xFF6750A4)
val KuttyPrimaryDark = Color(0xFFD0BCFF)
val KuttySecondary = Color(0xFF625B71)
