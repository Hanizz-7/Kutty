# Kutty — Phase 1

This is the Phase 1 source project: basic Compose UI with a toggleable mic button.
Nothing is wired to real speech recognition yet — that's Phase 2.

## How to open this

1. Unzip the folder anywhere on your computer.
2. Open **Android Studio** → **Open** → select the unzipped `Kutty` folder.
3. Android Studio will detect there's no Gradle wrapper jar included (it was left
   out to keep this zip small and because it's a binary file) and will prompt you
   to **"Create Gradle Wrapper"** — click yes/accept. This downloads the correct
   Gradle version automatically. If it doesn't prompt automatically, go to
   **File → Sync Project with Gradle Files**, or right click `build.gradle.kts` → **Sync**.
4. Let Gradle sync finish (first time may take a few minutes — it's downloading
   AndroidX/Compose dependencies from Google's Maven repo).
5. Click the green **Run ▶** button with an emulator or physical device selected.

## Getting an APK

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

The output APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

Copy that file to your phone and install it (enable "install unknown apps" for
whatever app you use to open it).

## Package name

Everything is currently under `com.yourname.kutty`. If you want to rename it,
use Android Studio's **Refactor → Rename** on the package folder rather than
manually editing files, so all references update together.

## What's next

Phase 2 adds real speech-to-text so the mic button actually listens and shows
your transcribed words on screen. Let me know once Phase 1 runs successfully
on your device.
